# Time-series-analysis-in-Python
I perform time series analysis of data from scratch. I also implement The Autoregressive (AR) Model, The Moving Average (MA) Model, The Autoregressive Moving Average (ARMA) Model, The Autoregressive Integrated Moving Average (ARIMA) Model, The ARCH Model, The GARCH model, Auto ARIMA, forecasting and exploring a business case.

Index2018.csv is the dataset used for time series analysis in this project
